function cost=costfunc_public(z,MM,alp,mumu,nummesgs)

    cost=0;
    
    nstates=size(alp,1);
    nlinks=size(alp,2);
    degree=size(alp,3)-1;
    npaths=size(MM,1);
    
    %% intermediate variables
    x=zeros(npaths,nummesgs);
    y=zeros(npaths,1);
    pi=zeros(nstates,nummesgs);
    
    for k=1:nummesgs
        x(:,k)=z((k-1)*npaths+1:k*npaths,1);
    end
    y(:,1)=z(nummesgs*npaths+1:(nummesgs+1)*npaths,1);
    for omega=1:nstates
        pi(omega,:)=z((nummesgs+1)*npaths+(omega-1)*nummesgs+1:(nummesgs+1)*npaths+omega*nummesgs,1)';
    end
    
    %% total link flow in terms of decision variables
    fpath=zeros(npaths,nummesgs);
    flink=zeros(nlinks,nummesgs);
        
    for k=1:nummesgs
        for i=1:npaths
            fpath(i,k)=x(i,k)+y(i,1);
        end
        flink(:,k)=MM'*fpath(:,k);
    end
    
    %% construct cost 
    for j=1:nlinks
        for k=1:nummesgs
            for omega=1:nstates
                for d=0:degree
                    cost=cost+alp(omega,j,d+1)*flink(j,k)^(d+1)*pi(omega,k)*mumu(omega);
                end
            end
        end
    end
    
end