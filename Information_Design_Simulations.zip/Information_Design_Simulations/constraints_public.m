function [c,ceq] = constraints_public(z,MM,alp,mumu,nummesgs)
    c = [];
    ceq = [];
    
    nstates=size(alp,1);
    nlinks=size(alp,2);
    degree=size(alp,3)-1;
    npaths=size(MM,1);
    
    %% intermediate variables
    x=zeros(npaths,nummesgs);
    y=zeros(npaths,1);
    pi=zeros(nstates,nummesgs);
    
    for k=1:nummesgs
        x(:,k)=z((k-1)*npaths+1:k*npaths,1);
    end
    y(:,1)=z(nummesgs*npaths+1:(nummesgs+1)*npaths,1);
    for omega=1:nstates
        pi(omega,:)=z((nummesgs+1)*npaths+(omega-1)*nummesgs+1:(nummesgs+1)*npaths+omega*nummesgs,1)';
    end
    
    %% total link flow in terms of decision variables
    fpath=zeros(npaths,nummesgs);
    flink=zeros(nlinks,nummesgs);
        
    for k=1:nummesgs
        for i=1:npaths
            fpath(i,k)=x(i,k)+y(i,1);
        end
        flink(:,k)=MM'*fpath(:,k);
    end
    
    %% expected path delays for P agent
    ELL=zeros(npaths,nummesgs);
        
    for i=1:npaths
        for omega=1:nstates
            for k=1:nummesgs
                for d=0:degree
                    for j=1:nlinks
                        ELL(i,k)=ELL(i,k)+MM(i,j)*alp(omega,j,d+1)*flink(j,k)^d*pi(omega,k)*mumu(omega);
                    end
                end
            end
        end
    end
        
    %% expected link delays for N agent
    ELLsum=zeros(npaths,1);
        
    for i=1:npaths
        ELLsum(i,1)=sum(ELL(i,:));
    end
    
    %% inequality constraints
    for i=1:npaths
        for j=1:npaths
            if i ~= j
                for k=1:nummesgs
                    c=cat(2,c,x(i,k)*(ELL(i,k)-ELL(j,k))); %% nash for P agents
                end
                c=cat(2,c,y(i,1)*(ELLsum(i,1)-ELLsum(j,1))); %% nash for N agents
            end
        end
    end
end