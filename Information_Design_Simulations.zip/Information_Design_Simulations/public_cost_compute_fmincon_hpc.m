function [cost_all_pfracs,soln_all_pfracs] = public_cost_compute_fmincon_hpc(Mat,alp,mu,lambda,...
    min_pfrac,max_pfrac,delta_pfrac,nmesgs,ntrials)

    nstates=size(alp,1);
    npaths=size(Mat,1);
    
    num_pfrac=1+(max_pfrac-min_pfrac)/abs(delta_pfrac);
    
    cost_all_pfracs=1000*ones(1,num_pfrac); % choose a large number such as 1000
    soln_all_pfracs=zeros((nmesgs+1)*npaths+nstates*nmesgs,num_pfrac);
    
    Aineq_public=-eye((nmesgs+1)*npaths+nstates*nmesgs);
    bineq_public=zeros((nmesgs+1)*npaths+nstates*nmesgs,1);
        
    Aeq_public=zeros(nmesgs+1+nstates,(nmesgs+1)*npaths+nstates*nmesgs);
    beq_public=zeros(nmesgs+1+nstates,1);
        
    for i=1:nmesgs
        Aeq_public(i,(i-1)*npaths+1:i*npaths)=ones(1,npaths);
    end
    Aeq_public(nmesgs+1,nmesgs*npaths+1:(nmesgs+1)*npaths)=ones(1,npaths);
    for i=1:nstates
        Aeq_public(nmesgs+1+i,(nmesgs+1)*npaths+(i-1)*nmesgs+1:(nmesgs+1)*npaths+i*nmesgs)=ones(1,nmesgs);
        beq_public(nmesgs+1+i,1)=1;
    end
    
    z0=zeros((nmesgs+1)*npaths+nstates*nmesgs,1); 
    
    %% for loop for pfrac
    for p=1:num_pfrac
        pfrac=max_pfrac+(p-1)*delta_pfrac;
        
        for i=1:nmesgs
            beq_public(i,1)=lambda*pfrac;
        end
        beq_public(nmesgs+1,1)=lambda*(1-pfrac);
        
        for tau=1:ntrials   
            % initial condition
            for i=1:nmesgs
                z0((i-1)*npaths+1:i*npaths,1)=lambda*pfrac*randsimplex(npaths);
            end
            z0(nmesgs*npaths+1:(nmesgs+1)*npaths,1)=lambda*(1-pfrac)*randsimplex(npaths);
            for i=1:nstates
                z0((nmesgs+1)*npaths+(i-1)*nmesgs+1:(nmesgs+1)*npaths+i*nmesgs,1)=randsimplex(nmesgs);
            end
                
            [soln_temp,cost_temp]=fmincon(@(z)costfunc_public(z,Mat,alp,mu,nmesgs),z0,Aineq_public,bineq_public,Aeq_public,beq_public,...
                [],[], @(z) constraints_public(z,Mat,alp,mu,nmesgs));
                
            if cost_temp<cost_all_pfracs(:,p)
                cost_all_pfracs(:,p)=cost_temp;
                soln_all_pfracs(:,p)=soln_temp;
            end
            
        end
        
    end
end

