function cost_full_info_all_pfracs=full_info_cost_compute_hpc(Mat,alp,mu,lambda,...
    min_pfrac,max_pfrac,delta_pfrac)
    
    nstates=size(alp,1);
    %nlinks=size(alp,2);
    npaths=size(Mat,1);
    num_pfrac=1+(max_pfrac-min_pfrac)/abs(delta_pfrac);
    
    cost_full_info_all_pfracs=[];
    
    %% matrices to be used for computing flows for the full info case
    %X=cat(2,eye(nstates*nlinks),kron(ones(nstates,1),eye(nlinks)));
    Aineq_full=zeros(1,(nstates+1)*npaths);
    bineq_full=0;
    Aeq_full=kron(eye(nstates+1),ones(1,npaths));
    lb_full=zeros((nstates+1)*npaths,1);
    ub_full=lambda*ones((nstates+1)*npaths,1);
    
    %% for loop for pfrac
    for p=1:num_pfrac
        pfrac=max_pfrac+(p-1)*delta_pfrac;
        
        %% social cost for the full information case
        beq_full=cat(1,pfrac*lambda*ones(nstates,1),(1-pfrac)*lambda);
        x0=zeros((nstates+1)*npaths,1);
        x=fmincon(@(x) costfunc_nash_full(x,Mat,alp,mu),x0,Aineq_full,bineq_full,Aeq_full,beq_full,lb_full,ub_full);
        cost_full_info_pfrac=costfunc_full_eval(x,Mat,alp,mu);
        cost_full_info_all_pfracs=cat(2,cost_full_info_all_pfracs,cost_full_info_pfrac);
    end
end