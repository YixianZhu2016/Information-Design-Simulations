function c=costfunc(x,MM,alp,w)
    degree=size(alp,3)-1;
    numlinks=size(alp,2);
    
    c=0;
    for i=1:numlinks
        for d=0:degree
            c=c+alp(w,i,d+1)*(MM(:,i)'*x)^(d+1)/(d+1);
        end
    end
end