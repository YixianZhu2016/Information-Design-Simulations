function varargout = pow10(varargin)

varargout{1} = 10.^varargin{1};
