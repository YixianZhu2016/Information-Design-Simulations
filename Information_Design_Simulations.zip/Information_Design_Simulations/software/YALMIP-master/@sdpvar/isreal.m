function res = isreal(Y)
%ISREAL (overloaded)

res = isreal(Y.basis);
