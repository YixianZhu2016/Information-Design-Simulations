function varargout = log2(varargin)

varargout{1} = log(varargin{1})/log(2);