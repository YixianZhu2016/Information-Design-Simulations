function X = ncvar(X)
X = ncvar(struct(X));