%% Last modified: August 26 2021
%% compute optimal private cost under atomic signals

function [status_all_pfracs,cost_all_pfracs,soln_all_pfracs] = private_cost_compute_hpc(Mat,alp,mu,lambda,...
    min_pfrac,max_pfrac,delta_pfrac,param_num,natoms)

addpath /Users/.../Information_Design_Simulations/software/gloptipoly3 %% add path to the software directory
addpath /Users/.../Information_Design_Simulations/software/sedumi-master %% add path to the software directory
addpath /Users/.../Information_Design_Simulations/software/YALMIP-master %% add path to the software directory


nstates=size(alp,1);
nlinks=size(alp,2);
degree=size(alp,3)-1;
npaths=size(Mat,1);

num_pfrac=1+(max_pfrac-min_pfrac)/abs(delta_pfrac);

status_all_pfracs=[];
cost_all_pfracs =[];
soln_all_pfracs=zeros((natoms+1)*(npaths-1)+nstates*(natoms-1),num_pfrac);

%% for loop for pfrac
for p=1:num_pfrac
    pfrac=max_pfrac+(p-1)*delta_pfrac;
    
    %% start with a clean workspace
    mset clear;
    mset clearmeas;
    
    %% defining polynomial decision variables; NEED TO MANUALLY ENTER THE SIZE of z in mpol
    % size of z: (natoms+1) * (npaths-1) + nstates * (natoms-1);
    switch param_num
        case 1
            mpol z 5;
        case 2
            mpol z 12;
        case 3
            mpol z 16;
    end
    
    %%
    % z(1): P agent path 1 flow under atom 1
    % ...
    % z(nlinks-1): P agent path npaths-1 flow under atom 1
    % ...
    % z((natoms-1)*(nlinks-1)+1): P agent path 1 flow under atom natoms
    % ...
    % z(natoms*(nlinks-1)): P agent path npaths-1 flow under atom natoms
    % z(natoms*(nlinks-1)+1): N agent path 1 flow
    % ...
    % z((natoms+1)*(nlinks-1)): N agent path npaths-1 flow
    % z((natoms+1)*(nlinks-1)+1): probability of atom 1 under state 1
    % ...
    % z((natoms+1)*(nlinks-1)+natoms-1): probability of atom natoms-1 under state 1
    % ...
    % z((natoms+1)*(nlinks-1)+(nstates-1)*(natoms-1)+1): probability of atom 1 under state nstates
    % ...
    % z((natoms+1)*(nlinks-1)+nstates*(natoms-1)): probability of atom natoms-1 under state nstates
    
    %% path flows for P agents in terms of polynomial decision variables in z
    x=z(1)*zeros(npaths,natoms);
    
    for k=1:natoms
        for i=1:npaths-1
            x(i,k)=z((k-1)*(npaths-1)+i);
        end
        x(npaths,k)=lambda*pfrac-sum(x(1:npaths-1,k));
    end
    
    
    
    %% path flows for N agents in terms of polynomial decision variables in z
    y=z(1)*zeros(npaths,1);
    
    for i=1:npaths-1
        y(i,1)=z(natoms*(npaths-1)+i);
    end
    y(npaths,1)=lambda*(1-pfrac)-sum(y(1:npaths-1,1));
    
    %% signal entries in terms of polynomial decision variables in z
    pi=z(1)*zeros(nstates,natoms);
    
    for omega=1:nstates
        for k=1:natoms-1
            pi(omega,k)=z((natoms+1)*(npaths-1)+(omega-1)*(natoms-1)+k);
        end
        pi(omega,natoms)=1-sum(pi(omega,1:natoms-1));
    end
    
    %% total path and link flow in terms of polynomial decision variables
    fpath=z(1)*zeros(npaths,natoms);
    flink=z(1)*zeros(nlinks,natoms);
    
    for k=1:natoms
        for i=1:npaths
            fpath(i,k)=x(i,k)+y(i,1);
        end
        flink(:,k)=Mat'*fpath(:,k);
    end
    
    %% expected path delays for P agent
    ELL=z(1)*zeros(npaths,natoms);
    
    for i=1:npaths
        for omega=1:nstates
            for k=1:natoms
                for d=0:degree
                    for j=1:nlinks
                        ELL(i,k)=ELL(i,k)+Mat(i,j)*alp(omega,j,d+1)*flink(j,k)^d*pi(omega,k)*mu(omega);
                    end
                end
            end
        end
    end
    
    %% expected link delays for N agent
    ELLsum=z(1)*zeros(npaths,1);
    
    for i=1:npaths
        ELLsum(i,1)=sum(ELL(i,:));
    end
    
    %% define measures
    m=meas;
    
    %% cost function
    g0=0;
    for j=1:nlinks
        for k=1:natoms
            for omega=1:nstates
                for d=0:degree
                    g0=g0+alp(omega,j,d+1)*flink(j,k)^(d+1)*pi(omega,k)*mu(omega);
                end
            end
        end
    end
    
    %% support of the measure
    K=[];
    
    for i=1:npaths
        for k=1:natoms
            K=cat(2,K,x(i,k)>=0);
        end
        K=cat(2,K,y(i,1)>=0);
    end
    
    for omega=1:nstates
        for k=1:natoms
            K=cat(2,K,pi(omega,k)>=0);
        end
    end
    
    %% inequality constraints
    for i=1:npaths
        for j=1:npaths
            if i ~= j
                oc=0;
                for k=1:natoms
                    oc=oc+x(i,k)*(ELL(i,k)-ELL(j,k));
                end
                K=cat(2,K,oc<=0); %% obedience for P agents
                K=cat(2,K,y(i,1)*(ELLsum(i,1)-ELLsum(j,1))<=0); %% nash for N agents
            end
        end
    end
    
    %% mass of the measure is equal to one
    L=[];
    L=cat(2,L,mass(z)==1);
    
    %% solve the SDP
    status=0;
    ntrials=1;
    pars.eps=1e-9;
    mset(pars);
    while status~=1 && ntrials <=3
        P = msdp(min(g0),K,L,3);
        [status,obj]=msol(P);
        ntrials=ntrials+1;
    end
    obj;
    status_all_pfracs=cat(2,status_all_pfracs,status);
    cost_all_pfracs=cat(2,cost_all_pfracs,obj);
    if status==1
        soln_this_pfrac=double(z);
        soln_all_pfracs(:,p)=soln_this_pfrac(:,:,1);
    end
end
end