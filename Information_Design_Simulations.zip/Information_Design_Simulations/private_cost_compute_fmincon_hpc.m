function [cost_all_pfracs,soln_all_pfracs] = private_cost_compute_fmincon_hpc(Mat,alp,mu,lambda,...
    min_pfrac,max_pfrac,delta_pfrac,natoms,ntrials)
    
    nstates=size(alp,1);
    npaths=size(Mat,1);
    
    num_pfrac=1+(max_pfrac-min_pfrac)/abs(delta_pfrac);
    
    cost_all_pfracs=1000*ones(1,num_pfrac); % choose a large number such as 1000
    soln_all_pfracs=zeros((natoms+1)*npaths+nstates*natoms,num_pfrac);
    
    Aineq_private=-eye((natoms+1)*npaths+nstates*natoms);
    bineq_private=zeros((natoms+1)*npaths+nstates*natoms,1);
        
    Aeq_private=zeros(natoms+1+nstates,(natoms+1)*npaths+nstates*natoms);
    beq_private=zeros(natoms+1+nstates,1);
    
    
    
    for i=1:natoms
        Aeq_private(i,(i-1)*npaths+1:i*npaths)=ones(1,npaths);
    end
    Aeq_private(natoms+1,natoms*npaths+1:(natoms+1)*npaths)=ones(1,npaths);
    for i=1:nstates
        Aeq_private(natoms+1+i,(natoms+1)*npaths+(i-1)*natoms+1:(natoms+1)*npaths+i*natoms)=ones(1,natoms);
        beq_private(natoms+1+i,1)=1;
    end
    
    z0=zeros((natoms+1)*npaths+nstates*natoms,1); 
    
     %% for loop for pfrac
    for p=1:num_pfrac
        pfrac=max_pfrac+(p-1)*delta_pfrac;
        
        for i=1:natoms
            beq_private(i,1)=lambda*pfrac;
        end
        beq_private(natoms+1,1)=lambda*(1-pfrac);
        
        for tau=1:ntrials   
            % initial condition
            for i=1:natoms
                z0((i-1)*npaths+1:i*npaths,1)=lambda*pfrac*randsimplex(npaths);
            end
            z0(natoms*npaths+1:(natoms+1)*npaths,1)=lambda*(1-pfrac)*randsimplex(npaths);
            for i=1:nstates
                z0((natoms+1)*npaths+(i-1)*natoms+1:(natoms+1)*npaths+i*natoms,1)=randsimplex(natoms);
            end
            
            [soln_temp,cost_temp]=fmincon(@(z)costfunc_private(z,Mat,alp,mu,natoms),z0,Aineq_private,bineq_private,Aeq_private,beq_private,...
                [],[], @(z) constraints_private(z,Mat,alp,mu,natoms));
                
            if cost_temp<cost_all_pfracs(:,p)
                cost_all_pfracs(:,p)=cost_temp;
                soln_all_pfracs(:,p)=soln_temp;
            end
            
        end
        
    end

end
