%% Last modified: August 26 2021
%% main file for info design; this version for a general directed graph between a single OD pair

%% prefix to filename
fname_prefix=fullfile('/Users','...','Information_Design_Simulations'); %% add path to the main file

scenarionum=1; %% set of parameters to be used for simulations
natoms=2; %% number of atoms for private signals
nmesgs=2; %% number of messages for public signals

nstarts=100; %% number of random initializations

%% range of pfrac values
min_pfrac=0.0;
max_pfrac=1.0;
delta_pfrac=-0.05;
num_pfrac=1+(max_pfrac-min_pfrac)/abs(delta_pfrac);

%% load the parameters
param_file=fullfile(fname_prefix,strcat('params_',num2str(scenarionum),'.mat'));
load(param_file);

%% pfrac values
pfrac_array=[];
for p=1:num_pfrac
    pfrac=max_pfrac+(p-1)*delta_pfrac;
    pfrac_array=cat(2,pfrac_array,pfrac);
end
fname=fullfile(fname_prefix,strcat('pfrac_vals_',num2str(scenarionum),'.mat'));
save(fname,'pfrac_array');

%% cost under optimal private signals

% gloptipoly approach
if 1
    [status_private_gloptipoly,cost_private_gloptipoly,solution_private_gloptipoly]=private_cost_compute_hpc(M,alpha,prior,demand,min_pfrac,...
        max_pfrac,delta_pfrac,scenarionum,natoms);
    cost_private_gloptipoly;
end

% fmincon approach
if 1
    [cost_private_fmincon,solution_private_fmincon]=private_cost_compute_fmincon_hpc(M,alpha,prior,demand,...
        min_pfrac,max_pfrac,delta_pfrac,natoms,nstarts);
    cost_private_fmincon;
    solution_private_fmincon;
end

if 1
    cost_private=cost_private_fmincon;
    fname=fullfile(fname_prefix,strcat('cost_private_',num2str(scenarionum),'.mat'));
    save(fname,'cost_private');
    solution_private=solution_private_fmincon;
    fname=fullfile(fname_prefix,strcat('solution_private_',num2str(scenarionum),'.mat'));
    save(fname,'solution_private');
end

% plot the difference between gloptipoly and fmincon approaches
if 1
    delta_cost_private=cost_private_fmincon-cost_private_gloptipoly;
    delta_cost_percent_private=rdivide(delta_cost_private,(cost_private_fmincon+cost_private_gloptipoly)/2)*100;  
    fname=fullfile(fname_prefix,strcat('delta_cost_percent_private_',num2str(scenarionum),'.mat'));
    save(fname,'delta_cost_percent_private');
end


%% cost under optimal public signals

% gloptipoly approach
if 1
    [status_public_gloptipoly,cost_public_gloptipoly,solution_public_gloptipoly]=public_cost_compute_hpc(M,alpha,prior,demand,min_pfrac,...
        max_pfrac,delta_pfrac,scenarionum,nmesgs);
    cost_public_gloptipoly;
end

% fmincon approach
if 1
    [cost_public_fmincon,solution_public_fmincon]=public_cost_compute_fmincon_hpc(M,alpha,prior,demand,...
        min_pfrac,max_pfrac,delta_pfrac,nmesgs,nstarts);
    cost_public_fmincon;
    solution_public_fmincon;
end

% plot the difference between gloptipoly and fmincon approaches
if 1
    delta_cost_public=cost_public_fmincon-cost_public_gloptipoly;
    delta_cost_percent_public=rdivide(delta_cost_public,(cost_public_fmincon+cost_public_gloptipoly)/2)*100;
    fname=fullfile(fname_prefix,strcat('delta_cost_percent_public_',num2str(scenarionum),'.mat'));
    save(fname,'delta_cost_percent_public');
end

if 1    
    cost_public=cost_public_fmincon;
    solution_public=solution_public_fmincon;
    fname=fullfile(fname_prefix,strcat('cost_public_',num2str(scenarionum),'.mat'));
    save(fname,'cost_public');
    fname=fullfile(fname_prefix,strcat('solution_public_',num2str(scenarionum),'.mat'));
    save(fname,'solution_public');
end


%% cost under full information signal
if 1
    cost_full_info=full_info_cost_compute_hpc(M,alpha,prior,demand,min_pfrac,...
        max_pfrac,delta_pfrac);
    fname=fullfile(fname_prefix,strcat('cost_full_info_',num2str(scenarionum),'.mat'));
    save(fname,'cost_full_info');
    cost_full_info;
end

%% minimum possible social cost 
if 1
    opt_social_cost=opt_social_cost_compute_hpc(M,alpha,prior,demand);
    cost_social=opt_social_cost*ones(1,num_pfrac);
    fname=fullfile(fname_prefix,strcat('cost_social_',num2str(scenarionum),'.mat'));
    save(fname,'cost_social');
end
