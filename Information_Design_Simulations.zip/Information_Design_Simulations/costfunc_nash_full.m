function c=costfunc_nash_full(x,MM,alp,mu)
    
    numstates=size(alp,1);
    numlinks=size(alp,2);
    numpaths=size(MM,1);
    degree=size(alp,3)-1;
    
    c=0;
    for i=1:numlinks
        for d=0:degree
            for w=1:numstates
                c=c+alp(w,i,d+1)*(MM(:,i)'*(x((w-1)*numpaths+1:w*numpaths)+x(numstates*numpaths+1:(numstates+1)*numpaths)))^(d+1)*mu(w)/(d+1);
            end
        end
    end
end