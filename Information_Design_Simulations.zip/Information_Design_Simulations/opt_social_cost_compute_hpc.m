function cost=opt_social_cost_compute_hpc(Mat,alp,mu,lambda)
    
    nstates=size(alp,1);
    npaths=size(Mat,1);
    
    Aineq=zeros(1,npaths);
    bineq=0;
    Aeq=ones(1,npaths);
    beq=lambda;
    lb=zeros(npaths,1);
    ub=lambda*ones(npaths,1);
    x0=zeros(npaths,1);
    
    cost_omega_all=[];
    for omega=1:nstates 
        [x,cost_omega]=fmincon(@(x) costfunc(x,Mat,alp,omega),x0,Aineq,bineq,Aeq,beq,lb,ub);
        cost_omega_all=cat(2,cost_omega_all,cost_omega);
    end
    cost=mu*cost_omega_all';
    %cost=0;
end