function [c,ceq] = constraints_private(z,MM,alp,mumu,numatoms)
    c = [];
    ceq = [];
    
    nstates=size(alp,1);
    nlinks=size(alp,2);
    degree=size(alp,3)-1;
    npaths=size(MM,1);
    
    %% intermediate variables
    x=zeros(npaths,numatoms);
    y=zeros(npaths,1);
    pi=zeros(nstates,numatoms);
    
    for k=1:numatoms
        x(:,k)=z((k-1)*npaths+1:k*npaths,1);
    end
    y(:,1)=z(numatoms*npaths+1:(numatoms+1)*npaths,1);
    for omega=1:nstates
        pi(omega,:)=z((numatoms+1)*npaths+(omega-1)*numatoms+1:(numatoms+1)*npaths+omega*numatoms,1)';
    end
    
    %% total link flow in terms of decision variables
    fpath=zeros(npaths,numatoms);
    flink=zeros(nlinks,numatoms);
        
    for k=1:numatoms
        for i=1:npaths
            fpath(i,k)=x(i,k)+y(i,1);
        end
        flink(:,k)=MM'*fpath(:,k);
    end
    
    %% expected path delays for P agent
    ELL=zeros(npaths,numatoms);
        
    for i=1:npaths
        for omega=1:nstates
            for k=1:numatoms
                for d=0:degree
                    for j=1:nlinks
                        ELL(i,k)=ELL(i,k)+MM(i,j)*alp(omega,j,d+1)*flink(j,k)^d*pi(omega,k)*mumu(omega);
                    end
                end
            end
        end
    end
        
    %% expected link delays for N agent
    ELLsum=zeros(npaths,1);
        
    for i=1:npaths
        ELLsum(i,1)=sum(ELL(i,:));
    end
    
    %% inequality constraints
    for i=1:npaths
        for j=1:npaths
            if i ~= j
                oc=0;
                for k=1:numatoms
                    oc=oc+x(i,k)*(ELL(i,k)-ELL(j,k));
                end
                c=cat(2,c,oc); %% obedience for P agents
                c=cat(2,c,y(i,1)*(ELLsum(i,1)-ELLsum(j,1))); %% nash for N agents
            end
        end
    end
end