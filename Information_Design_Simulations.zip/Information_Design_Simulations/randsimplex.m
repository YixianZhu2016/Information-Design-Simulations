%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% uniform sample from an n-simplex
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p = randsimplex(n)
    ptemp=rand(n-1,1);
    ptemp=sort(ptemp);
    ptemp=cat(1,0,ptemp);
    ptemp=cat(1,ptemp,1);
    p=zeros(n,1);
    for i=1:n
        p(i,1)=ptemp(i+1,1)-ptemp(i,1);
    end
end