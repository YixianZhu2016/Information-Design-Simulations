function cost=costfunc_private(z,MM,alp,mumu,numatoms)

    cost=0;
    
    nstates=size(alp,1);
    nlinks=size(alp,2);
    degree=size(alp,3)-1;
    npaths=size(MM,1);
    
    %% intermediate variables
    x=zeros(npaths,numatoms);
    y=zeros(npaths,1);
    pi=zeros(nstates,numatoms);
    
    for k=1:numatoms
        x(:,k)=z((k-1)*npaths+1:k*npaths,1);
    end
    y(:,1)=z(numatoms*npaths+1:(numatoms+1)*npaths,1);
    for omega=1:nstates
        pi(omega,:)=z((numatoms+1)*npaths+(omega-1)*numatoms+1:(numatoms+1)*npaths+omega*numatoms,1)';
    end
    
    %% total link flow in terms of decision variables
    fpath=zeros(npaths,numatoms);
    flink=zeros(nlinks,numatoms);
        
    for k=1:numatoms
        for i=1:npaths
            fpath(i,k)=x(i,k)+y(i,1);
        end
        flink(:,k)=MM'*fpath(:,k);
    end
    
    %% construct cost 
    for j=1:nlinks
        for k=1:numatoms
            for omega=1:nstates
                for d=0:degree
                    cost=cost+alp(omega,j,d+1)*flink(j,k)^(d+1)*pi(omega,k)*mumu(omega);
                end
            end
        end
    end
    
end